create view deaths(template, died, killed_by, created_at) as
SELECT chat_death.template,
       CASE
           WHEN death_templates.killer_is_first THEN chat_death.player_2
           ELSE chat_death.player_1
           END AS died,
       CASE
           WHEN death_templates.killer_is_first IS NULL THEN NULL::text
           WHEN death_templates.killer_is_first THEN chat_death.player_1
           ELSE chat_death.player_2
           END AS killed_by,
       chat_death.created_at
FROM chat_death
         LEFT JOIN death_templates USING (template);

alter table deaths
    owner to postgres;

