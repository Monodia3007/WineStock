create function new_server() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
    INSERT INTO last_by_server (server_id, created_at)
    VALUES (NEW.server_id, 0)
    ON CONFLICT ON CONSTRAINT last_by_server_pkey DO NOTHING;
    RETURN NEW;
END;
$$;

alter function new_server() owner to postgres;

