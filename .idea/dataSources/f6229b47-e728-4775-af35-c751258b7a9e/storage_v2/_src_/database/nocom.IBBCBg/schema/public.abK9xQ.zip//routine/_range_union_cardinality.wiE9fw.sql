create function _range_union_cardinality(int8range[]) returns bigint
    language plpgsql
as
$$

DECLARE
    _range    int8range;
    _current  int8range;
    _duration bigint;

BEGIN

    _current := (SELECT x FROM unnest($1) x ORDER BY x LIMIT 1);
    _duration := 0::bigint;

    FOR _range IN SELECT unnest($1) x ORDER BY x
        LOOP
            IF _range && _current OR _range -|- _current THEN
                _current := _current + _range;
            ELSE
                _duration := _duration + UPPER(_current) - LOWER(_current);
                _current := _range;
            END IF;
        END LOOP;

    RETURN _duration + UPPER(_current) - LOWER(_current);
END;

$$;

alter function _range_union_cardinality(int8range[]) owner to postgres;

