create view assoc(username, cluster_id, association) as
SELECT players.username,
       tmp.cluster_id,
       tmp.association
FROM (SELECT associations.cluster_id,
             associations.player_id,
             sum(associations.association) AS association
      FROM associations
      GROUP BY associations.player_id, associations.cluster_id) tmp
         JOIN players ON players.id = tmp.player_id;

alter table assoc
    owner to postgres;

