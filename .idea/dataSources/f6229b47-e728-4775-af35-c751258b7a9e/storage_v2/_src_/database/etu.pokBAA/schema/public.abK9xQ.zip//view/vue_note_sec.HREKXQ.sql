create view vue_note_sec(eno, mat, cno, valeur) as
SELECT note.eno,
       note.mat,
       note.cno,
       note.valeur
FROM note;

alter table vue_note_sec
    owner to postgres;

