create view vue_moy_mat(mat, moyenneu) as
SELECT n.mat,
       sum(n.valeur * c.coeff::numeric) / sum(c.coeff)::numeric AS moyenneu
FROM vue_note_etu n
         JOIN controle c USING (mat, cno)
GROUP BY n.mat;

alter table vue_moy_mat
    owner to postgres;

