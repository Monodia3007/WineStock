create view vue_algo(eno, cno, valeur) as
SELECT note.eno,
       note.cno,
       note.valeur
FROM note
WHERE note.mat::text = 'algo'::text
ORDER BY note.cno;

alter table vue_algo
    owner to postgres;

