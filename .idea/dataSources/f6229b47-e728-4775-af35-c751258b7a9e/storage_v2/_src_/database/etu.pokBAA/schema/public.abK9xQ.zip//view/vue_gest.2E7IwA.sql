create view vue_gest(eno, cno, valeur) as
SELECT note.eno,
       note.cno,
       note.valeur
FROM note
WHERE note.mat::text = 'gestion'::text
ORDER BY note.cno;

alter table vue_gest
    owner to postgres;

