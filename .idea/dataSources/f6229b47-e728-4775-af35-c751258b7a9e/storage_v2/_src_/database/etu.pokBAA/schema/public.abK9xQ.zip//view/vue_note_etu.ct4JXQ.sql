create view vue_note_etu(mat, cno, valeur) as
SELECT n.mat,
       n.cno,
       n.valeur
FROM note n
         JOIN etudiant e USING (eno)
WHERE e.login::text = USER;

alter table vue_note_etu
    owner to postgres;

