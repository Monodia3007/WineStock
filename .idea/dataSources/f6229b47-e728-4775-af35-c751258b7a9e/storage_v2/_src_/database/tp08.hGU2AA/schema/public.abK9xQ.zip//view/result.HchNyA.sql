create view result(nom, prenom) as
SELECT n.nom,
       p.prenom
FROM prenoms p
         JOIN asso a ON p.pno = a.pno
         JOIN noms n ON a.nno = n.nno;

alter table result
    owner to postgres;

